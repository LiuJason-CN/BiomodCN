#include<stdio.h>
main()//A-0,G-1,C-2,T-3,,,-1��������,-1���´��������� 
{//����ؽ�����ʷ�� 
	void input(int (*s)[100]);
	int sort(int (*s)[100],int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4]);
	void d4(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r);
	void d6(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r);
	int lfind(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r);
	int ldis(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r,int w);
	void pack(int (*s)[100],int (*t)[10],int r);
	void show(int (*s)[100],int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4]);
	int seq[10][100],mod[4][4][4][4][6],team[18][10],note[18][10][4],rr,ww=1,zz,i=0;
	input(seq);
	rr=sort(seq,mod,team,note);
	d4(mod,team,note,rr);
	d6(mod,team,note,rr);
	pack(seq,team,rr);
	while(i<50)//(ww!=-1)
	{
		ww=lfind(mod,team,note,rr);//printf("%d\n",ww);
		if((zz=ldis(mod,team,note,rr,ww))==1)
			pack(seq,team,rr);i++;//printf("zz=%d\n",zz);
	}
	//show(seq,mod,team,note);
} 
void input(int (*s)[100])
{
	int i,j,n;
	char ch;
	printf("Please input the number of ssDNA:");
		scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		printf("Please input the code of ssDNA%d:\n",i+1);
		printf("123456789 123456789 123456789 123456789 \
123456789 123456789 123456789 \n");
		for(j=0;;j++)
		{
			ch=getchar();
			if(ch!='\n') *(*(s+i)+j)=ch;
				else break;
		}
		for(;j<100;j++) *(*(s+i)+j)=-1;
	}
	for(;i<10;i++) for(j=0;j<100;j++) *(*(s+i)+j)=-1;
}
int sort(int (*s)[100],int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4])
{
	int sos(int (*se)[100]);
	void som(int (*me)[4][4][4][6]);
	void sot(int (*te)[10],int a);
	void son(int (*ne)[10][4],int a);
	int aa;
	aa=sos(s);
	som(m);
	sot(t,aa);
	son(n,aa);
	return aa;
}
int sos(int (*se)[100])
{
	int i,j,k,n,m=0,z;
	for(n=97;n<123;n++)
		for(z=i=0;*(*(se+i)+0)!=-1&&z==0;i++)
			for(j=0;*(*(se+i)+j)!=-1&&z==0;j++)
				if(*(*(se+i)+j)==n)
				{
					m++;
					z=1;
				}
	return m;
}
void som(int (*me)[4][4][4][6])
{
	int g,h,i,j,k;
	for(g=0;g<4;g++)
		for(h=0;h<4;h++)
			for(i=0;i<4;i++)
				for(j=0;j<4;j++)
					for(k=0;k<6;k++)
						switch(k)
						{
							case 0:*(*(*(*(*(me+g)+h)+i)+j)+k)=g;break;
							case 1:*(*(*(*(*(me+g)+h)+i)+j)+k)=h;break;
							case 2:*(*(*(*(*(me+g)+h)+i)+j)+k)=i;break;
							case 3:*(*(*(*(*(me+g)+h)+i)+j)+k)=j;break;
							case 4:*(*(*(*(*(me+g)+h)+i)+j)+k)=-1;break;
							case 5:*(*(*(*(*(me+g)+h)+i)+j)+k)=-1;break;
						}
	for(i=4;i<6;i++)
	{
		*(*(*(*(*(me+0)+0)+0)+0)+i)=0;
		*(*(*(*(*(me+3)+3)+3)+3)+i)=0;
	}
}
void sot(int (*te)[10],int a)
{
	int i,j;
	for(i=0;i<a;i++)
		for(j=0;j<10;j++)
			*(*(te+i)+j)=-1;
	for(;i<18;i++)
		for(j=0;j<10;j++)
			*(*(te+i)+j)=-2;
}
void son(int (*ne)[10][4],int a)
{//1-���ã�2-������ 
	int i,j,k;
	for(i=0;i<a;i++)
		for(j=0;j<10;j++)
			for(k=0;k<4;k++)
				*(*(*(ne+i)+j)+k)=1;
	for(;i<18;i++)
		for(j=0;j<10;j++)
			for(k=0;k<4;k++)
				*(*(*(ne+i)+j)+k)=2;
}
void d4(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r)
{
	void asn(int (*te)[10],int (*ne)[10][4],int w);
	int g,h,i,j,k,z;
	for(g=0;g<r;g++)
		for(z=h=0;h<4&&z==0;h++)
			for(i=0;i<4&&z==0;i++)
				for(j=0;j<4&&z==0;j++)
					for(k=0;k<4&&z==0;k++)
						if(*(*(*(*(*(m+h)+i)+j)+k)+4)==-1)
						{
							*(*(t+g)+0)=h;*(*(t+g)+1)=i;*(*(t+g)+2)=j;*(*(t+g)+3)=k;
							asn(t,n,g);
							*(*(*(*(*(m+h)+i)+j)+k)+4)=0;
							*(*(*(*(*(m+3-k)+3-j)+3-i)+3-h)+4)=0;
							z=1;
						}
}
void asn(int (*te)[10],int (*ne)[10][4],int w)
{
	int g,h,i,j,k;
	for(g=0;g<4;g++) *(*(*(ne+w)+0)+g)=1;
	if(w<16)
	{
		for(g=0;g<4;g++) *(*(*(ne+w)+1)+g)=1;
		if(w>11)
		{
			for(g=0;g<3;g++) *(*(*(ne+w)+2)+g)=0;
			*(*(*(ne+w)+2)+3)=1;
		}
		else if(w>7)
		{
			for(g=0;g<2;g++) *(*(*(ne+w)+2)+g)=0;
			for(g=2;g<3;g++) *(*(*(ne+w)+2)+g)=1;
		}
		else if(w>3)
		{
			*(*(*(ne+w)+2)+0)=0;
			for(g=1;g<3;g++) *(*(*(ne+w)+2)+g)=1;
		}
		else for(g=0;g<3;g++) *(*(*(ne+w)+2)+g)=1;
	}
	else
	{
		*(*(*(ne+w)+1)+0)=0;
		for(g=1;g<4;g++) *(*(*(ne+w)+1)+g)=1;
		for(g=0;g<4;g++) *(*(*(ne+w)+2)+g)=*(*(*(ne+w)+3)+g)=1;
		if(w==17) *(*(*(ne+w)+3)+0)=0;
	}
	switch(w)
	{
		case 0:{for(g=0;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 1:{*(*(*(ne+w)+3)+0)=0;for(g=1;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 2:{*(*(*(ne+w)+3)+0)=*(*(*(ne+w)+3)+1)=0;
			*(*(*(ne+w)+3)+2)=*(*(*(ne+w)+3)+3)=1;}break;
		case 3:{for(g=0;g<3;g++) *(*(*(ne+w)+3)+g)=0;*(*(*(ne+w)+3)+3)=1;}break;
		case 4:{for(g=0;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 5:{*(*(*(ne+w)+3)+0)=0;for(g=1;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 6:{*(*(*(ne+w)+3)+0)=*(*(*(ne+w)+3)+1)=0;
			*(*(*(ne+w)+3)+2)=*(*(*(ne+w)+3)+3)=1;}break;
		case 7:{for(g=0;g<3;g++) *(*(*(ne+w)+3)+g)=0;*(*(*(ne+w)+3)+3)=1;}break;
		case 8:{for(g=0;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 9:{*(*(*(ne+w)+3)+0)=0;for(g=1;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 10:{*(*(*(ne+w)+3)+0)=*(*(*(ne+w)+3)+1)=0;
			*(*(*(ne+w)+3)+2)=*(*(*(ne+w)+3)+3)=1;}break;
		case 11:{for(g=0;g<3;g++) *(*(*(ne+w)+3)+g)=0;*(*(*(ne+w)+3)+3)=1;}break;
		case 12:{for(g=0;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 13:{*(*(*(ne+w)+3)+0)=0;for(g=1;g<4;g++) *(*(*(ne+w)+3)+g)=1;}break;
		case 14:{*(*(*(ne+w)+3)+0)=*(*(*(ne+w)+3)+1)=0;
			*(*(*(ne+w)+3)+2)=*(*(*(ne+w)+3)+3)=1;}break;
		case 15:{for(g=0;g<3;g++) *(*(*(ne+w)+3)+g)=0;*(*(*(ne+w)+3)+3)=1;}break;
	}
}
void d6(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r)
{
	int dis(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int ,int);
	int back(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int ,int ,int);
	int i,j,u,v;
	for(j=4;j<10;j++)
		for(i=0;i<r;i++)
			if((u=dis(m,t,n,i,j))==0)
			{
				v=back(m,t,n,r,i,j);//printf("%d\n",v);
				j=v%100;
				i=(v-j)/100;
				//j=100;
				//i=100;
			}/**/
}
int dis(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i1,int j1)
{//ֻ���˼�¼����û�и�t/m 
	int a,b,c,k,u=4,v;
	a=*(*(te+i1)+j1-3);b=*(*(te+i1)+j1-2);c=*(*(te+i1)+j1-1);
	for(k=3;k>-1;k--)
	{
		if(*(*(*(*(*(me+a)+b)+c)+k)+4)==0)
		{
			*(*(*(ne+i1)+j1)+k)=0;
			u--;
		}
		else
			v=k;
	}
	if(u>0)
	{
		*(*(te+i1)+j1)=v;
		*(*(*(*(*(me+a)+b)+c)+v)+4)=0;
		*(*(*(*(*(me+3-v)+3-c)+3-b)+3-a)+4)=0;
	}
	return u;
}
int back(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i1,int j1)
{
	int find(int (*nee)[10][4],int i3,int j3,int ree);
	void b3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int j1,int j2);
	int i,j,k,k1,k2,i2,j2,a,e,f,g,h,b,c,n;
	a=find(ne,i1,j1,re);
		j2=a%100;
		i2=(a-j2)/100;//printf("%d ",a);
	//for(k=0;k<4;k++) printf("%d",*(*(*(ne+3)+4)+k));printf("    ");
	if(j2>2)
	{
		b3(me,te,ne,re,j1,j2);
		for(i=re-1;i>i2;i--)
			if(*(*(te+i)+j2)!=-1)//ע��һ����j2 
			{
				for(k=0;k<4;k++) *(*(*(ne+i)+j2)+k)=1;
				e=*(*(te+i)+j2-3);f=*(*(te+i)+j2-2);g=*(*(te+i)+j2-1);h=*(*(te+i)+j2);
				*(*(*(*(*(me+e)+f)+g)+h)+4)=-1;
				*(*(*(*(*(me+3-h)+3-g)+3-f)+3-e)+4)=-1;
				*(*(te+i)+j2)=-1;
			}
		e=*(*(te+i2)+j2-3);f=*(*(te+i2)+j2-2);g=*(*(te+i2)+j2-1);h=*(*(te+i2)+j2);
		*(*(*(ne+i2)+j2)+h)=0;
		for(k=3;k>-1;k--) if(*(*(*(ne+i2)+j2)+k)==1) b=k;
		*(*(te+i2)+j2)=b;
		for(k=0;k<4;k++) *(*(*(ne+i1)+j1)+k)=1;
		*(*(*(*(*(me+e)+f)+g)+h)+4)=-1;*(*(*(*(*(me+3-h)+3-g)+3-f)+3-e)+4)=-1;
		*(*(*(*(*(me+e)+f)+g)+b)+4)=0;*(*(*(*(*(me+3-b)+3-g)+3-f)+3-e)+4)=0;
		return (100*i2+j2);
	}
	else if(j2==2)
	{//printf("%d ",i2);
		b3(me,te,ne,re,j1,j2);
		c=*(*(te+i2)+j2);
		*(*(*(ne+i2)+j2)+c)=0;//printf("%d ",*(*(*(ne+i2)+j2)+c));
		for(k=3;k>-1;k--) if(*(*(*(ne+i2)+j2)+k)==1) *(*(te+i2)+j2)=k;
		for(k=0;k<4;k++) *(*(*(ne+i1)+j1)+k)=1;
		//printf("%d ",*(*(*(ne+i2)+j2)+0));{printf("%d ",k);}
		for(i=i2+1;i<re;i++)
			for(k=3;k>-1;k--)
			{
				e=*(*(te+i)+0);f=*(*(te+i)+1);
				for(n=j=0;j<i;j++)
					if(*(*(te+j)+0)==e&&*(*(te+j)+1)==f&&*(*(te+j)+2)==k) n++;
				if(n<4)
				{
					*(*(te+j)+2)=k;
					*(*(*(ne+j)+j2)+k)=1;
				}
				else *(*(*(ne+j)+j2)+k)=0;
			}//
		return(100*re-98);
	}
}
void b3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int j1,int j2)
{
	int i,j,k,e,f,g,h;
	for(j=j1;j>j2;j--)
		for(i=re-1;i>-1;i--)
			if(*(*(te+i)+j)!=-1)
			{
				for(k=0;k<4;k++) *(*(*(ne+i)+j)+k)=1;
				e=*(*(te+i)+j-3);f=*(*(te+i)+j-2);g=*(*(te+i)+j-1);h=*(*(te+i)+j);
				*(*(*(*(*(me+e)+f)+g)+h)+4)=-1;
				*(*(*(*(*(me+3-h)+3-g)+3-f)+3-e)+4)=-1;
				*(*(te+i)+j)=-1;
			}
}
int find(int (*nee)[10][4],int i3,int j3,int ree)
{
	int i4,j4,i,j,k,n,z=0;
	i4=j4=-1;
	for(i=i3;i>-1;i--)
	{
		for(n=k=0;k<4;k++) if(*(*(*(nee+i)+j3)+k)==1) n++;
		if(n>1)
		{
			i4=i;
			j4=j3;
			break;
		}
	}
	if(i4==-1)
		for(j=j3-1;j>-1&&z==0;j--)
			for(i=ree-1;i>-1&&z==0;i--)
			{
				for(n=k=0;k<4;k++) if(*(*(*(nee+i)+j)+k)==1) n++;
				if(n>1)
				{
					i4=i;
					j4=j;
					z=1;
				}
			}
	return(100*i4+j4);
}
int lfind(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r)
{
	void lf2(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i1,int j1);
	void lf1(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i1,int j1);
	void l2(int (*te)[10],int (*ne)[10][4],int i1,int j1);
	void l1(int (*te)[10],int (*ne)[10][4],int i1,int j1);
	int i,j,k,g,z=0,i2=-1,j2=-1;
	for(j=9;j>-1&&z==0;j--)
		for(i=r-1;i>-1&&z==0;i--)
		{
			for(g=k=0;k<4;k++)
				if(*(*(*(n+i)+j)+k)==1)
					g++;//printf("g=%d\n",g);
			if(g>1)
			{
				z=1;
				i2=i;j2=j;//printf("j=%d\n",j);
				if(j>2)
					lf2(m,t,n,i,j);
				else
					l2(t,n,i,j);
			}
			else
			{
				if(j>2)
					lf1(m,t,n,i,j);
				else
					l1(t,n,i,j);
			}
		}//printf("%d %d\n",i2,j2);
	if(i2!=-1)
		return(100*i2+j2);
	else
		return -1;
}
void lf2(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i1,int j1)
{
	int k,a,b,c,d,e;
	a=*(*(te+i1)+j1-3);b=*(*(te+i1)+j1-2);c=*(*(te+i1)+j1-1);d=*(*(te+i1)+j1);
		*(*(*(ne+i1)+j1)+d)=0;
	for(k=3;k>-1;k--)
		if(*(*(*(ne+i1)+j1)+k)==1)
			*(*(te+i1)+j1)=k;
	e=*(*(te+i1)+j1);
	*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
		*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;
	*(*(*(*(*(me+a)+b)+c)+e)+4)=0;
		*(*(*(*(*(me+3-e)+3-c)+3-b)+3-a)+4)=0;//printf("j=%d\n",j);
}
void lf1(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i1,int j1)
{
	int k,a,b,c,d;
	a=*(*(te+i1)+j1-3);b=*(*(te+i1)+j1-2);c=*(*(te+i1)+j1-1);d=*(*(te+i1)+j1);
	*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
		*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;
	for(k=0;k<4;k++)
		*(*(*(ne+i1)+j1)+k)=0;//��ʱ���붼Ϊ0���������� 
	*(*(te+i1)+j1)=-1;
}
void l2(int (*te)[10],int (*ne)[10][4],int i1,int j1)
{
	int k,a;
	a=*(*(te+i1)+j1);
	*(*(*(ne+i1)+j1)+a)=0;
	for(k=3;k>-1;k--)
		if(*(*(*(ne+i1)+j1)+k)==1)
			*(*(te+i1)+j1)=k;
}
void l1(int (*te)[10],int (*ne)[10][4],int i1,int j1)
{
	int k;
	for(k=0;k<4;k++)
		*(*(*(ne+i1)+j1)+k)=0;
	*(*(te+i1)+j1)=-1;
}
int ldis(int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4],int r,int w)
{
	int ldb3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i1,int j1);
	int ldb2(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re);
	int i1,j1,a,b;
	j1=w%100;i1=(w-j1)/100;
	if(j1>2)
	{
		a=ldb3(m,t,n,r,i1,j1);//printf("j1=%d\na=%d\n",j1,a);
		return a;
	}
	else if(j1==2)return 0;
	
		//while(()==1)
		//b=ldb3(m,t,n,r,r-1,2)
	
	else if(j1==1)return 0;
	else return 0;
}
int ldb3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i1,int j1)
{
	int lb0(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i3,int j3);
	int ld3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i3,int j3);
	int lb3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i3,int j3,int i4,int j4);
	int i,j,g,h,a,z;//printf("%d %d %d\n",i1,j1,re);
		for(i=i1+1;i<re&&z==0;i++)
			if((g=ld3(me,te,ne,re,i,j1))==0)
			{
				if((h=lb3(me,te,ne,re,i,j1,i1,j1))==-1)
				{
					z=1;//printf("!!!\n");
					return 0;
				}
				else
				{//printf("!!!!!!\n");
					j=h%100;
					i=(h-j)/100;	
					if(j==j1&&i==i1)
						if((a=lb0(me,te,ne,i1,j1))==0)
						{
							z=1;
							return 0;
						}
				}
			}
	for(z=0,j=j1+1;j<10&&z==0;j++)
		for(i=0;i<re&&z==0;i++)
			if((g=ld3(me,te,ne,re,i,j))==0)
			{
				if((h=lb3(me,te,ne,re,i,j,i1,j1))==-1)
				{
					z=1;//printf("!!!\n");
					return 0;
				}
				else
				{//printf("!!!!!!\n");
					j=h%100;
					i=(h-j)/100;	
					if(j==j1&&i==i1)
						if((a=lb0(me,te,ne,i1,j1))==0)
						{
							z=1;
							return 0;
						}
				}
			}
	if(z==0) return 1;
}
int lb0(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int i3,int j3)
{
	int k,a,b,c,d,e=-1,n;
	a=*(*(te+i3)+j3-3);b=*(*(te+i3)+j3-2);c=*(*(te+i3)+j3-1);d=*(*(te+i3)+j3);
		*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
			*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;
		*(*(*(ne+i3)+j3)+d)=0;
		*(*(te+i3)+j3)=-1;
	for(n=0,k=3;k>-1;k--)
		if(*(*(*(ne+i3)+j3)+k)==1)//ע�⣡�������� 
			e=*(*(te+i3)+j3)=k;
	if(e==-1)
		return 0;
	else
	{
		*(*(*(*(*(me+a)+b)+c)+e)+4)=0;
			*(*(*(*(*(me+3-e)+3-c)+3-b)+3-a)+4)=0;
		return 1;
	}
}
int ld3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i3,int j3)
{//printf("!!!!!!!!!!!!!!\n");
	int k,a,b,c,z=0;//printf("t=%d\n",*(*(te+i3)+j3));
	a=*(*(te+i3)+j3-3);b=*(*(te+i3)+j3-2);c=*(*(te+i3)+j3-1);
	for(k=0;k<4;k++)
		if(*(*(*(*(*(me+a)+b)+c)+k)+4)==-1)
		{
			*(*(te+i3)+j3)=k;
			*(*(*(*(*(me+a)+b)+c)+k)+4)=0;
				*(*(*(*(*(me+3-k)+3-c)+3-b)+3-a)+4)=0;
			*(*(*(ne+i3)+j3)+k)=1;
			z=1;
			break;
		}//printf("t=%d\n",*(*(te+i3)+j3));
	if(z==1)
	{
		for(k=0;k<4;k++)
			if(*(*(*(*(*(me+a)+b)+c)+k)+4)==-1)
				*(*(*(ne+i3)+j3)+k)=1;
		return 1;
	}
	else
		return 0;
}
int lb3(int (*me)[4][4][4][6],int (*te)[10],int (*ne)[10][4],int re,int i3,int j3,int i4,int j4)
{
	int i,j,k,i5=-1,j5=-1,n,z=0,a,b,c,d,e;
	for(j=j3;j>j4-1&&z==0;j--)
		for(i=re-1;i>-1&&z==0;i--)
			if(*(*(te+i)+j)!=-1)
			{
				for(n=k=0;k<4;k++)
					if(*(*(*(ne+i)+j)+k)==1)
						n++;
				if(n>1)
				{
					i5=i;
					j5=j;
					z=1;
				}
			}
	if(i5==-1||j5==-1||j5==j4&&i5<i4)
		return -1;
	else
	{
		for(z=0,j=j3;j>j5;j--)
			for(i=re-1;i>-1;i--)
				if(*(*(te+i)+j)!=-1)
				{
					a=*(*(te+i)+j-3);b=*(*(te+i)+j-2);c=*(*(te+i)+j-1);d=*(*(te+i)+j);
						*(*(te+i)+j)=-1;
					*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
						*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;
					for(k=0;k<4;k++)
						*(*(*(ne+i)+j)+k)=0;
				}
		for(i=re-1;i>i5;i--)
		{
			a=*(*(te+i)+j5-3);b=*(*(te+i)+j5-2);c=*(*(te+i)+j5-1);d=*(*(te+i)+j5);
				*(*(te+i)+j5)=-1;
			*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
				*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;////ע�⣡�������� 
			for(k=0;k<4;k++)
				*(*(*(ne+i)+j5)+k)=0;
		}
		a=*(*(te+i)+j5-3);b=*(*(te+i)+j5-2);c=*(*(te+i)+j5-1);d=*(*(te+i)+j5);
		for(k=3;k>-1;k--)
			if(*(*(*(*(*(me+a)+b)+c)+k)+4)==-1)
				e=k;
		*(*(te+i5)+j5)=e;
			*(*(*(ne+i5)+j5)+d)=0;
		*(*(*(*(*(me+a)+b)+c)+d)+4)=-1;
			*(*(*(*(*(me+3-d)+3-c)+3-b)+3-a)+4)=-1;
		*(*(*(*(*(me+a)+b)+c)+e)+4)=0;
			*(*(*(*(*(me+3-e)+3-c)+3-b)+3-a)+4)=0;
		return(100*i5+j5);
	}
}
void pack(int (*s)[100],int (*t)[10],int r)
{
	void record(int (*sr)[100]);
	int i,j,i1,j1,i2,j2,k,sr[10][100],z,a[18];//printf("%d",r);
	for(i=0;i<18;i++) a[i]=0;
	for(i=0;i<10;i++)
		for(j=0;j<100;j++)
		{
			if(*(*(s+i)+j)==48) sr[i][j]=3;
			else if(*(*(s+i)+j)==-1) sr[i][j]=-1;
			else sr[i][j]=*(*(s+i)+j);
		}
	for(k=97;k<123;k++)
		for(z=i=0;i<r&&z==0;i++)
			for(j=0;*(*(s+i)+j)!=-1&&z==0;j++)
				if(*(*(s+i)+j)==k)
					for(i1=0;i1<10&&z==0;i1++)
						if(a[i1]!=-1)
						{
							for(j1=0;j1<10;j1++,j++)
								*(*(sr+i)+j)=*(*(t+i1)+j1);
							a[i1]=-1;
							z=1;
						}
	for(k=97;k<123;k++)
		for(z=i=0;i<r&&z==0;i++)
			for(j=0;*(*(s+i)+j)!=-1&&z==0;j++)
			{
				if(*(*(sr+i)+j)==k)
				{
					for(i1=0;i1<10;i1++)
						*(*(sr+i)+j+i1)=3-*(*(sr+i2)+j2+9-i1);
					z=1;
				}
				if(*(*(s+i)+j)==k)
				{
					i2=i;
					j2=j;
					j+=10;//printf("%d %d\n",i2,j2);
				}
			}
	/*for(i=0;*(*(s+i)+0)!=-1;i++)
	{
		for(j=0;j<100;j++) printf("%d",sr[i][j]);
		printf("\n");
	}*/
	record(sr);
}
void record(int (*sr)[100])
{
	FILE *fp;
	int i,j;
	char ch[5];
	ch[0]='A';ch[1]='G';ch[2]='C';ch[3]='T';ch[4]='\n';
	if((fp=fopen("ql.doc","ab"))==NULL)
	{
		printf("can't!\n");
		exit(0);
	}
	for(i=0;*(*(sr+i)+0)!=-1;i++)
	{
		for(j=0;*(*(sr+i)+j)!=-1;j++)
			switch(*(*(sr+i)+j))
			{
				case 0:fputc(ch[0],fp);break;
				case 1:fputc(ch[1],fp);break;
				case 2:fputc(ch[2],fp);break;
				case 3:fputc(ch[3],fp);break;
			}
		fputc(ch[4],fp);
	}fputc(ch[4],fp);
	fclose(fp);
}
show(int (*s)[100],int (*m)[4][4][4][6],int (*t)[10],int (*n)[10][4])
{
	void ss(int (*se)[100]);
	void sm(int (*me)[4][4][4][6]);
	void st(int (*te)[10]);
	void sn(int (*ne)[10][4]);
	ss(s);
	sm(m);
	st(t);
	sn(n);
}
void ss(int (*se)[100])
{
	int i,j;
	for(i=0;i<10;i++)
	{
		for(j=0;j<100;j++) printf("%d",*(*(se+i)+j));
		printf("\n");
	}
}
void sm(int (*me)[4][4][4][6])
{
	int g,h,i,j,k;
	for(h=0;h<4;h++)
		for(i=0;i<4;i++)
			for(j=0;j<4;j++)
			{
				for(k=0;k<4;k++)
				{
					for(g=0;g<6;g++) printf("%d",*(*(*(*(*(me+h)+i)+j)+k)+g));
					printf("  ");
				}
				printf("\n");
			}
}
void st(int (*te)[10])
{
	int i,j;
	for(i=0;i<18;i++)
	{
		for(j=0;j<10;j++) printf("%d",*(*(te+i)+j));
		printf("\n");
	}
}
void sn(int (*ne)[10][4])
{
	int i,j,k;
	for(i=0;i<18;i++)
	{
		for(j=0;j<10;j++)
		{
			for(k=0;k<4;k++) printf("%d",*(*(*(ne+i)+j)+k));
			printf(" ");
		}
		printf("\n");
	}
}